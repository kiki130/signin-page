import React from "react";

function Card({ userInfo }) {
  return (
    <div className="card" style={{ width: "18rem" }}>
      <ul className="list-group list-group-flush">
        <li className="list-group-item">{userInfo.userName}</li>
        <li className="list-group-item">{userInfo.email}</li>
        <li className="list-group-item">{userInfo.contact}</li>
      </ul>
    </div>
  );
}

export default Card;
