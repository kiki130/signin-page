import React, { useState, useEffect, useMemo } from 'react'
import Card from '../cart/Cart';
import { Container } from 'react-bootstrap';

import './style.css'

export const Signup = () => {
    const [userInfo, setUserInfo] = useState({});

    const test = () => {
        var userName = document.getElementById("username");
        var email = document.getElementById("email");
        var contact = document.getElementById("contact");
        var detail = {userName : userName.value , email : email.value , contact : contact.value }
        setUserInfo(detail)

    }
    return (
        <>
            <div className='body'>
                <form>
                    <h1>Signup Page</h1>                    
                    
                    <table>
                        <tr>
                            <td>Fullname
                            </td>
                            <td>
                                <input type="text" name="username" id="username" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label htmlFor="username">Email</label>

                            </td>
                            <td>
                                <input type="text" name="email" id="email" />

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label htmlFor="username">Contact No.</label>

                            </td>
                            <td>
                                <input type="number" name="contact" id="contact" />

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <button type="button" onClick={test}>Button</button>
                            </td>
                        </tr>
                    </table>
                </form>

            </div>

            <Card userInfo={userInfo}></Card>

        </>
    )
}
export default Signup;