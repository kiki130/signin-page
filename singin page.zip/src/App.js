
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import SignUp from './components/signup';

function App() {
  
  return (
    
    <>
    <SignUp></SignUp>
    </>
  );
}

export default App;
